package com.capgemini.junitesting;
import com.capgemini.dao.Lib_daoimpl;
import com.capgemini.dto.Lib_dto;
import com.capgemini.dto.Lib_dto;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Before;

import com.capgemini.dao.DButil;
import com.capgemini.exception.FilenotfoundException;

public class Lib_daotest {
	
	
	
	
	
	public Connection getConnection() throws ClassNotFoundException,SQLException,FilenotfoundException
	{
		final Connection con;
		
		try{
		
		String jdbcdriver= "oracle.jdbc.driver.OracleDriver";
		Class.forName(jdbcdriver);
		String jdbcURL = "jdbc:oracle:thin:@localhost:1521:XE";
		String userName = "System";
		String password = "platitude02";
		
		con = DriverManager.getConnection(jdbcURL, userName, password);
		
		}

		catch(SQLException se)
		{
			throw new FilenotfoundException("connection not possible "+se.getMessage());
		
		}
		
	return con;
	}
	
	
	
	@Test
	public void testInsertissuedetails() throws FilenotfoundException, ClassNotFoundException, SQLException
	{
		Connection con;
		Lib_daotest lb= new Lib_daotest();
	    con= lb.getConnection();
		String sql = "insert into books_registration values(001,'stu01')";
		Lib_dto dto= new Lib_dto();
		dto.setBook_id(001);
		dto.setStudent_id("stu01");
		
		
	
	
		
	}
}


