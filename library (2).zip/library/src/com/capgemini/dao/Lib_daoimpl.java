package com.capgemini.dao;
import com.capgemini.dto.Lib_dto;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.dto.Lib_dto;
import com.capgemini.exception.FilenotfoundException;

public class Lib_daoimpl implements Lib_dao{
	
	private Connection con;
	{
	try{
		
	// TODO Auto-generated method stub
	con= DButil.getConnection();
	} 
	catch(SQLException sq) {}
	catch(ClassNotFoundException cn) {}
	catch(FilenotfoundException cf) {}
}
	public void Insertissuedetails(Lib_dto dto) throws FilenotfoundException,ClassNotFoundException, SQLException
{
		
		String sql = "insert into books_registration values(?,?)";
		try {
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, dto.getStudent_id());
			pst.setString(2, dto.getBook_id());
			pst.execute();
		} 
		
		catch (SQLException e) {
			throw new FilenotfoundException("Problem in inserting the details "
							+e.getMessage());
		}
		
		
	}


}
